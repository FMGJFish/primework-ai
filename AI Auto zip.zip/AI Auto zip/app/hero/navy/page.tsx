import HeroCentered from "@/components/HeroCentered";

export default function Page() {
  return <HeroCentered variant="navy" />;
}
