// app/contact/page.tsx
import ContactForm from "components/ContactForm";
import Link from "next/link";

export const metadata = {
  title: "Contact • Primework AI",
  description: "Tell us about your workflow or website. We'll reply same day.",
};

export default function ContactPage() {
  return (
    <section className="bg-white">
      <div className="container py-16">
        <div className="max-w-3xl">
          <h1 className="text-3xl md:text-4xl font-semibold text-brand-ink">
            Tell us what you need. We’ll take it from here.
          </h1>
          <p className="mt-3 text-brand-ink/70">
            No pressure. No contracts. Just clarity. Expect a response the same day.
          </p>
        </div>

        <div className="mt-8 rounded-3xl border border-black/5 bg-white p-6 md:p-8 shadow-[0_8px_40px_-8px_rgba(0,0,0,0.08)] max-w-3xl">
          <ContactForm />
          <Link href="/contact" className="btn btn-outline">Talk to a human</Link>
        </div>
      </div>
    </section>
  );
}
